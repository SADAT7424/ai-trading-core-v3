"""
Unit tests for Position Management's pure calculations. Expected values are
hand-computed — see the verification step before these were written.
"""
from app.market_core.calculations import Trend
from app.positions.calculations import (
    ExitAction,
    ExitReason,
    ThesisHealthStatus,
    compute_target_price,
    compute_thesis_health,
    decide_exit,
)
from app.trading_core.calculations import Direction


def test_compute_target_price_long() -> None:
    assert compute_target_price(3600, 3550, Direction.LONG, r_multiple=2.0) == 3700.0


def test_compute_target_price_short() -> None:
    assert compute_target_price(3600, 3650, Direction.SHORT, r_multiple=2.0) == 3500.0


def test_thesis_health_fully_intact_scores_strong() -> None:
    health = compute_thesis_health(
        Direction.LONG,
        current_trend=Trend.BULLISH,
        entry_gold_macro_score=40,
        current_gold_macro_score=40,
    )
    assert health.score == 100
    assert health.status is ThesisHealthStatus.STRONG


def test_thesis_health_trend_flip_is_severe() -> None:
    health = compute_thesis_health(
        Direction.LONG,
        current_trend=Trend.BEARISH,
        entry_gold_macro_score=40,
        current_gold_macro_score=40,
    )
    assert health.score == 50  # 100 - 50 (trend opposed)
    assert health.status is ThesisHealthStatus.CRITICAL


def test_thesis_health_both_opposed_is_invalidated() -> None:
    health = compute_thesis_health(
        Direction.LONG,
        current_trend=Trend.BEARISH,
        entry_gold_macro_score=40,
        current_gold_macro_score=-40,
    )
    assert health.score == 15  # 100 - 50 - 35
    assert health.status is ThesisHealthStatus.INVALIDATED


def test_thesis_health_neutral_drift_is_weakening_not_invalidated() -> None:
    health = compute_thesis_health(
        Direction.LONG,
        current_trend=Trend.NEUTRAL,
        entry_gold_macro_score=40,
        current_gold_macro_score=5,  # no longer a strong tailwind, but not opposed
    )
    assert health.score == 65  # 100 - 20 (trend neutral) - 15 (macro no longer aligned)
    assert health.status is ThesisHealthStatus.WEAKENING


def test_decide_exit_hard_stop_wins_even_with_strong_thesis() -> None:
    """The single most important rule in this module — see docstring."""
    decision = decide_exit(
        Direction.LONG,
        current_price=3549,
        stop_price=3550,
        target_price=3700,
        thesis_status=ThesisHealthStatus.STRONG,
    )
    assert decision.action is ExitAction.EXIT
    assert decision.reason is ExitReason.STOP_LOSS


def test_decide_exit_target_reached() -> None:
    decision = decide_exit(
        Direction.LONG,
        current_price=3701,
        stop_price=3550,
        target_price=3700,
        thesis_status=ThesisHealthStatus.HEALTHY,
    )
    assert decision.action is ExitAction.EXIT
    assert decision.reason is ExitReason.TAKE_PROFIT


def test_decide_exit_invalidated_thesis_exits_even_mid_range() -> None:
    decision = decide_exit(
        Direction.LONG,
        current_price=3620,  # nowhere near stop or target
        stop_price=3550,
        target_price=3700,
        thesis_status=ThesisHealthStatus.INVALIDATED,
    )
    assert decision.action is ExitAction.EXIT
    assert decision.reason is ExitReason.THESIS_INVALIDATED


def test_decide_exit_holds_when_nothing_triggers() -> None:
    decision = decide_exit(
        Direction.LONG,
        current_price=3620,
        stop_price=3550,
        target_price=3700,
        thesis_status=ThesisHealthStatus.HEALTHY,
    )
    assert decision.action is ExitAction.HOLD
    assert decision.reason is ExitReason.NONE


def test_decide_exit_short_direction_mirrors_long() -> None:
    decision = decide_exit(
        Direction.SHORT,
        current_price=3651,  # above stop for a short -> stop breached
        stop_price=3650,
        target_price=3500,
        thesis_status=ThesisHealthStatus.STRONG,
    )
    assert decision.action is ExitAction.EXIT
    assert decision.reason is ExitReason.STOP_LOSS
