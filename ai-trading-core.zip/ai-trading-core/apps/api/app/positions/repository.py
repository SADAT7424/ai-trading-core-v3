"""
Database access for Position Management. Kept separate from calculations.py
so the exit/health logic stays pure and DB-free (see that module's
docstring).
"""
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.position import Position, PositionStatus


def get_open_positions(db: Session, symbol: str | None = None) -> list[Position]:
    query = select(Position).where(Position.status == PositionStatus.OPEN)
    if symbol is not None:
        query = query.where(Position.symbol == symbol)
    return list(db.execute(query.order_by(Position.opened_at.desc())).scalars().all())


def get_position(db: Session, position_id: str) -> Position | None:
    return db.get(Position, position_id)


def close_position(
    db: Session, position: Position, close_price: float, reason: str
) -> Position:
    direction_sign = 1 if position.direction == "LONG" else -1
    realized_pnl = (
        (close_price - float(position.entry_price)) * float(position.units) * direction_sign
    )

    position.status = PositionStatus.CLOSED
    position.close_price = close_price
    position.close_reason = reason
    position.realized_pnl = round(realized_pnl, 2)
    position.closed_at = datetime.now(UTC)

    db.commit()
    db.refresh(position)
    return position
