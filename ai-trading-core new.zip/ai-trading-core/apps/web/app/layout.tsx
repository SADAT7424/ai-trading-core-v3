import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GO OS",
  description: "AI Trading Core — Foundation build",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
